package com.languagetranslator.dao;

public enum Translation {
	;

	String getOriginalText() {
		// TODO Auto-generated method stub
		return null;
	}

	String getTranslatedText() {
		// TODO Auto-generated method stub
		return null;
	}

	String getSourceLang() {
		// TODO Auto-generated method stub
		return null;
	}

	String getTargetLang() {
		// TODO Auto-generated method stub
		return null;
	}

	int getId() {
		// TODO Auto-generated method stub
		return 0;
	}

}
