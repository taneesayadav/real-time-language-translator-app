package com.languagetranslator.dao;

public class DatabaseConnection {

}
